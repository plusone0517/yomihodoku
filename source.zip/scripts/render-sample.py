from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
root=Path(__file__).resolve().parents[1]
f='/usr/local/share/fonts/app-plan/NotoSansCJKjp-Regular.otf'
img=Image.new('RGB',(1300,1770),'white');d=ImageDraw.Draw(img)
font=lambda n:ImageFont.truetype(f,n)
d.text((100,80),'防災体験会のお知らせ',font=font(53),fill='#1b2c42')
d.text((890,169),'2026年9月30日',font=font(27),fill='#424a54')
d.text((925,215),'こもれび自治会',font=font(27),fill='#424a54')
d.line((90,274,1210,274),fill='#aab8c8',width=2)
lines=[('地域の皆さまを対象に、防災体験会を開催いたします。',326),('日時：2026年10月18日（日）午前10時から12時',430),('会場：こもれび公民館 2階 集会室',493),('対象者：地域にお住まいの方',556),('参加費：大人500円、子ども無料',619),('申込期限：2026年10月10日（土）必着',682),('参加を希望する方は、同封の申込書に必要事項を',810),('記入のうえ、自治会窓口へご提出ください。',865),('当日は、飲み物とタオルをご持参ください。',959),('小学生以下の方は、保護者と一緒にご参加ください。',1053),('事前の支払いは不要です。',1147),('参加費は当日、受付でお支払いください。',1202),('定員は30名です。先着順で受け付けます。',1296),('問い合わせ：こもれび自治会',1420),('電話：03-1234-5678（平日9時から17時）',1475)]
for t,y in lines:d.text((100,y),t,font=font(33),fill='#1f2731')
d.line((90,1590,1210,1590),fill='#c1cbd7',width=2)
d.text((100,1620),'このお知らせは、アプリの動作確認用の架空のサンプルです。',font=font(24),fill='#6c7683')
img.save(root/'public/sample-notice.jpg',quality=95)
