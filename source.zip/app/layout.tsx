import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "よみほどく｜やさしい説明アプリ",
  description: "書類の写真や文章から、やること・期限・金額をわかりやすく。元の書類と見比べて確認できます。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className="antialiased">{children}</body>
    </html>
  );
}
