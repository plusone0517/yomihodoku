import type {Explanation} from './explain';

// Only use complete excerpts; cutting a sentence can remove an important condition.
const compact=(value:string)=>value.replace(/\s+/g,' ').trim();
const shortExcerpt=(value:string,limit=180)=>{const s=compact(value);return s.length<=limit?s:'';};
export function nextSteps(r:Explanation){
 const action=r.restricted?'':r.actions.map(p=>shortExcerpt(p.text)).find(Boolean)||'';
 const deadlines=[...new Set(r.dates.filter(f=>f.kind==='締切・期限').map(f=>compact(f.context)))];
 return {action,deadlines};
}
export function familyMessage(r:Explanation){
 const {action,deadlines}=nextSteps(r);
 const deadline=deadlines.find(s=>s.length<=180);
 const lines=[
  '届いた書類の内容がよく分からないので、一緒に確認してもらえますか？',
  '',
  `【書類】${shortExcerpt(r.title,100)||'届いたお知らせ'}`,
  r.restricted?'【確認したいこと】専門的な内容のため、発行元への確認を手伝ってほしいです。':action?`【書類にある行動の候補】${action}`:'【確認したいこと】何をすればよいか、原文を一緒に確認したいです。',
  deadline?`【期限に関する記載】${deadline}`:deadlines.length?'【期限】記載があります。条件を含めて原文で確認したいです。':'【期限】読み取った文章からは見つけられませんでした。原文で確認したいです。',
  '',
  '自分に必要な手続きか、いつまでに何をすればよいか教えてもらえると助かります。',
  '※書類の一部を抜き出した説明です。条件や詳しい内容は元の書類で確認してください。'
 ];
 return lines.join('\n');
}
export const lineShareUrl=(text:string)=>'https://line.me/R/share?text='+encodeURIComponent(text);
