export type Term={word:string;reading:string;meaning:string};
export const glossary:Term[]=[
{word:'持参',reading:'じさん',meaning:'必要なものを持って行くこと。'},
{word:'提出',reading:'ていしゅつ',meaning:'書類などを、決められた相手に渡すこと。'},
{word:'申請',reading:'しんせい',meaning:'許可やサービスなどを受けるために、申し込むこと。'},
{word:'申込',reading:'もうしこみ',meaning:'参加や利用を希望すると伝えること。'},
{word:'必着',reading:'ひっちゃく',meaning:'その日までに、相手のところに届いている必要があります。'},
{word:'消印有効',reading:'けしいんゆうこう',meaning:'郵便局が押す消印の日付が、指定の日までなら受け付けられるという意味。'},
{word:'締切',reading:'しめきり',meaning:'申し込みなどを受け付ける最後の日や時刻。'},
{word:'期日',reading:'きじつ',meaning:'何かを行うために決められた日。'},
{word:'期限',reading:'きげん',meaning:'決められた、最後の日や時刻。'},
{word:'対象者',reading:'たいしょうしゃ',meaning:'このお知らせの条件が当てはまる人。'},
{word:'対象',reading:'たいしょう',meaning:'このお知らせで、当てはまる人やもの。'},
{word:'該当',reading:'がいとう',meaning:'書かれている条件に当てはまること。'},
{word:'実施',reading:'じっし',meaning:'予定したことを、実際に行うこと。'},
{word:'開催',reading:'かいさい',meaning:'集まりやイベントを開くこと。'},
{word:'受付',reading:'うけつけ',meaning:'申し込みや書類を受け取ること。また、その窓口。'},
{word:'同封',reading:'どうふう',meaning:'同じ封筒の中に、一緒に入れること。'},
{word:'添付',reading:'てんぷ',meaning:'書類やファイルを、別の書類などに付けること。'},
{word:'記入',reading:'きにゅう',meaning:'決められた欄に、文字や数字を書くこと。'},
{word:'記載',reading:'きさい',meaning:'書類などに書いてあること、または書くこと。'},
{word:'別紙',reading:'べっし',meaning:'この紙とは別の紙。'},
{word:'下記',reading:'かき',meaning:'この文章より下に書かれている内容。'},
{word:'上記',reading:'じょうき',meaning:'この文章より上に書かれている内容。'},
{word:'所定',reading:'しょてい',meaning:'あらかじめ決められていること。'},
{word:'所要時間',reading:'しょようじかん',meaning:'必要な時間。'},
{word:'定員',reading:'ていいん',meaning:'受け付ける人数の上限。'},
{word:'先着順',reading:'せんちゃくじゅん',meaning:'申し込みや到着が早い人から順に受け付けること。'},
{word:'抽選',reading:'ちゅうせん',meaning:'くじなどで選ぶこと。申し込んだ全員が選ばれるとは限りません。'},
{word:'任意',reading:'にんい',meaning:'自分で行うかどうかを選べること。'},
{word:'必須',reading:'ひっす',meaning:'必ず必要なこと。'},
{word:'不要',reading:'ふよう',meaning:'必要がないこと。'},
{word:'事前',reading:'じぜん',meaning:'そのことが始まる前。'},
{word:'当日',reading:'とうじつ',meaning:'そのことが行われる日。'},
{word:'翌日',reading:'よくじつ',meaning:'その次の日。'},
{word:'翌月',reading:'よくげつ',meaning:'その次の月。'},
{word:'各自',reading:'かくじ',meaning:'一人ひとり、それぞれで。'},
{word:'原則',reading:'げんそく',meaning:'基本の決まり。例外がある場合は、別に条件が書かれています。'},
{word:'原本',reading:'げんぽん',meaning:'コピーではなく、もとの書類そのもの。'},
{word:'写し',reading:'うつし',meaning:'もとの書類をコピーしたもの。'},
{word:'返送',reading:'へんそう',meaning:'届いたものを、送り返すこと。'},
{word:'郵送',reading:'ゆうそう',meaning:'郵便で送ること。'},
{word:'窓口',reading:'まどぐち',meaning:'相談や手続きを受け付ける場所。'},
{word:'手続き',reading:'てつづき',meaning:'申し込みなどに必要な作業を、決まりに沿って行うこと。'},
{word:'手続',reading:'てつづき',meaning:'申し込みなどに必要な作業を、決まりに沿って行うこと。'},
{word:'了承',reading:'りょうしょう',meaning:'内容を理解して、受け入れること。'},
{word:'欠席',reading:'けっせき',meaning:'集まりなどに参加しないこと。'},
{word:'延期',reading:'えんき',meaning:'予定していた日時を、あとにずらすこと。'},
{word:'中止',reading:'ちゅうし',meaning:'予定していたことを、行わないこと。'},
{word:'変更',reading:'へんこう',meaning:'決められていた内容を変えること。'},
{word:'有効',reading:'ゆうこう',meaning:'効き目や働きがある、または利用できる状態であること。'},
{word:'内訳',reading:'うちわけ',meaning:'合計の中に、何がどれだけ含まれているかを分けて示したもの。'},
{word:'税込',reading:'ぜいこみ',meaning:'税金を含んだ金額。'},
{word:'別途',reading:'べっと',meaning:'別に、という意味。費用なら、示された金額とは別にかかります。'},
{word:'後日',reading:'ごじつ',meaning:'今よりあとの日。これだけでは具体的な日は決まりません。'},
{word:'速やかに',reading:'すみやかに',meaning:'できるだけ早く、という意味。これだけでは具体的な期限は分かりません。'},
{word:'問い合わせ',reading:'といあわせ',meaning:'分からないことを、担当する人にたずねること。'},
{word:'問合せ',reading:'といあわせ',meaning:'分からないことを、担当する人にたずねること。'}
];
const rewrites:[string,string][]=[
['ご提出くださいますようお願いいたします','出してください'],['ご提出をお願いいたします','出してください'],['ご記入のうえ','書いてから'],['記入の上','書いてから'],['記入のうえ','書いてから'],
['ご持参ください','持ってきてください'],['持参してください','持ってきてください'],['持参すること','持ってくること'],
['ご提出ください','出してください'],['提出してください','出してください'],['提出願います','出してください'],
['お申し込みください','申し込んでください'],['お申込みください','申し込んでください'],
['ご記入ください','書いてください'],['記入してください','書いてください'],['ご確認ください','確認してください'],
['ご連絡ください','連絡してください'],['お問い合わせください','担当者にたずねてください'],
['ご返信ください','返事を送ってください'],['ご返送ください','送り返してください'],
['実施いたします','行います'],['実施します','行います'],['開催いたします','開きます'],['開催します','開きます'],
['お知らせいたします','お知らせします'],['ご案内いたします','案内します'],['お願いいたします','お願いします'],
['お持ちください','持ってきてください'],['お越しください','来てください'],['ご参加ください','参加してください'],
['必要事項','必要な内容'],['所要時間','かかる時間'],['対象者','当てはまる人'],['下記の','次の'],['上記の','前に書かれた'],['各自で','一人ひとりで'],
['申込書','申し込み用の書類'],['申請書','申し込み用の書類'],['添付資料','一緒に付ける資料'],['同封の','一緒に入っている']
];
export type Source={id:number;text:string};
export type Point={id:number;text:string;source:string};
export type Fact={id:number;value:string;context:string;kind:string};
export type Explanation={title:string;overview:Point[];details:Point[];actions:Point[];notes:Point[];dates:Fact[];amounts:Fact[];contacts:Fact[];terms:Term[];restricted:boolean;sources:Source[]};
const digits='[0-9０-９]';
const datePattern=new RegExp('(?:(?:令和|平成|昭和)\\s*(?:'+digits+'{1,2}|元)\\s*年\\s*|'+digits+'{4}\\s*年\\s*)?'+digits+'{1,2}\\s*月\\s*'+digits+'{1,2}\\s*日(?:\\s*[（(]\\s*[月火水木金土日](?:曜日)?\\s*[）)])?|'+digits+'{4}\\s*[／/.-]\\s*'+digits+'{1,2}\\s*[／/.-]\\s*'+digits+'{1,2}|(?:午前|午後)?\\s*'+digits+'{1,2}[：:]'+digits+'{2}|(?:午前|午後)?\\s*'+digits+'{1,2}\\s*時(?:\\s*'+digits+'{1,2}\\s*分)?','g');
const moneyPattern=/[0-9０-９][0-9０-９,，.．万千百十]*\s*円|無料|無償/g;
const contactPattern=/(?:[0-9０-９]{2,5}[-－ー‐―(（][0-9０-９]{1,4}[-－ー‐―)）][0-9０-９]{3,4})|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}|https?:\/\/[^\s<>"「」]+/g;
const protectedPattern=/[A-Za-z0-9０-９][A-Za-z0-9０-９@:/.\-_,，％%+()（）年月日時分円万千百十]*|(?:令和|平成|昭和)[0-9０-９元]+年[0-9０-９]+月[0-9０-９]+日/g;
export function simplify(s:string){const protectedText:string[]=[];let t=s.replace(protectedPattern,v=>{protectedText.push(v);return '\uE000'+String.fromCharCode(0xE100+protectedText.length-1)+'\uE001';});for(const [a,b] of rewrites)t=t.split(a).join(b);return t.replace(/\uE000([\uE100-\uF8FF])\uE001/g,(_,c)=>protectedText[c.charCodeAt(0)-0xE100]??'');}
export function explain(text:string):Explanation{
 if(typeof text!=='string'||text.trim().length<5)throw new Error('書類の文章を5文字以上入力してください。');
 if(text.length>16000)throw new Error('一度に整理できるのは16,000文字までです。');
 const lines:string[]=[];for(const line of text.split(/\r?\n/)){const l=line.trim();if(!l)continue;const previous=lines.at(-1);if(previous&&/[、，,をにはがのへともで]$/.test(previous)&&!/^.{1,10}[：:・]/.test(l))lines[lines.length-1]+='\n'+l;else lines.push(l);}const sources=lines.flatMap(line=>line.split(/(?<=[。！？])/)).map(s=>s.trim()).filter(Boolean).map((text,i)=>({id:i+1,text}));
 const restricted=/(処方箋|処方薬|服用|用法[・･\/]?用量|診断結果|検査結果|病理|手術同意|診療情報|契約条項|訴状|判決|納税通知|税額決定)/.test(text);
 const title=sources.find(s=>s.text.length>=4&&s.text.length<=90&&!/^([0-9０-９令和平成昭和元年月日().（）\s-]+)$/.test(s.text))?.text??'この書類のポイント';
 const map=(s:Source):Point=>({id:s.id,text:simplify(s.text),source:s.text});
 const negative=/(不要|必要ありません|必要はありません|必要がありません|提出しない|申し込まない|中止|禁止|できません|しないで|しなくて|しないこと)/;
 const action=/(ください|下さい|願います|お願いします|お願いいたします|必要です|すること|ご持参|要提出|提出が必要|提出をお願い|持参をお願い|ご返信)/;
 const note=/(ただし|但し|場合|のみ|変更|延期|中止|注意|原則|先着|抽選|必着|消印|任意|不要|必要ありません|必要はありません|できません)/;
 const actions=restricted?[]:sources.filter(s=>action.test(s.text)&&!negative.test(s.text)&&!/^.*(?:問い合わせ|問合せ).*[：:]/.test(s.text)).map(map);
 const notes=sources.filter(s=>note.test(s.text)&&!actions.some(a=>a.id===s.id)).map(map);
 const details=sources.filter(s=>/^(会場|場所|対象者|対象|定員|持ち物|受付場所|持参物|必要書類|主催)[：:・\s]|定員は/.test(s.text)).map(map);
 const overview=sources.filter(s=>s.text!==title&&!/^[0-9０-９年月日時分令和平成昭和元()（）.\/／\s-]+$/.test(s.text)&&!actions.some(a=>a.id===s.id)&&!notes.some(a=>a.id===s.id)&&!details.some(a=>a.id===s.id)&&!/(^[^：:・]{1,12}[：:・]|電話|[0-9０-９].*円|問い合わせ|申込期限|締切|締め切り|架空のサンプル)/.test(s.text)&&s.text.length>10).slice(0,3).map(map);
 function extract(pattern:RegExp,kind:(s:string)=>string):Fact[]{return sources.flatMap(s=>Array.from(s.text.matchAll(pattern),m=>({id:s.id,value:m[0],context:s.text,kind:kind(s.text)})));}
 const dates=extract(datePattern,s=>/(締切|締め切り|期限|必着|消印|までに)/.test(s)?'締切・期限':/(開催|日時|日程|実施)/.test(s)?'開催・実施':'原文の日付・時刻').sort((a,b)=>['締切・期限','開催・実施','原文の日付・時刻'].indexOf(a.kind)-['締切・期限','開催・実施','原文の日付・時刻'].indexOf(b.kind));
 const amounts=extract(moneyPattern,s=>/(参加費|会費)/.test(s)?'参加費':/(料金|費用|金額)/.test(s)?'金額':'原文の金額');
 const contacts=extract(contactPattern,()=> '連絡先');
 // Keep the longest overlapping term (e.g. 対象者 before 対象).
 const terms=glossary.filter(t=>text.includes(t.word)).filter(t=>!glossary.some(o=>o.word!==t.word&&o.word.includes(t.word)&&text.includes(o.word)));
 return {title,overview:restricted?[]:overview,details,actions,notes,dates,amounts,contacts,terms,restricted,sources};
}
export function toText(r:Explanation){return [r.title,'','【主な内容】',...r.overview.map(p=>p.text),'','【やること（候補）】',...(r.actions.length?r.actions.map(p=>p.text):['具体的な行動は見つかりませんでした。原文を確認してください。']),'','【対象・場所など】',...r.details.map(p=>p.source),'','【日付・時刻】',...(r.dates.length?r.dates.map(f=>f.context):['記載を見つけられませんでした。']),'','【金額】',...(r.amounts.length?r.amounts.map(f=>f.context):['記載を見つけられませんでした。']),'','【連絡先】',...r.contacts.map(f=>f.context),'','【注意・条件】',...r.notes.map(p=>r.restricted?p.source:p.text),'','【ことばの意味】',...(r.restricted?['この書類は専門的な確認が必要です。原文と担当窓口で確認してください。']:r.terms.map(t=>t.word+'（'+t.reading+'）：'+t.meaning)),'','原文の抜き出しと、ことばの言い換えで整理しています。必ず元の書類と確認してください。'].join('\n');}
